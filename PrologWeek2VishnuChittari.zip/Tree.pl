%Vishnu Chittari

%1
count_nodes(leaf(_), X):- X is 0.
%basically counts the number of nodes that are present by going through the tree and we sum it all up in the end to provide us the correct answer.
count_nodes(node(Y, Z), X):-
count_nodes(Y,P),
count_nodes(Z,R),
X is P+R+1.

%2
tree_leaf(leaf(Y), X):-
(Y==X); 
false.
tree_leaf(node(Z,R),X):-
tree_leaf(Z,X);
tree_leaf(R,X).

%3
increment_tree(node(Y,P),node(R,W)):- %increments the values in a leaf and is done as provided, takes the values that are given and increments them.
increment_tree(Y,R),increment_tree(P,W).
increment_tree(leaf(Y),leaf(X)) :- 
    X is Y+1.

%4
subtree(leaf(R), leaf(R)).
subtree(node(R,P),X) :-
X=node(R,P);
subtree(R,X);
subtree(P,X).

%5
list_length([],0). 
list_length([_|T],Y) :- list_length(T,L), %provides us with the length of the input that we enter in and is incremented by 1 to provide us the correct answer.
Y is L+1. 


%6
list_element([Z|T],Z).
list_element([Y|T],Z) :- list_element(T,Z). %checks whether a certain element is present in the provide input or not


%7
increment_list([],[]).
increment_list([H|T],[X|Y]) :- %either increments the list provided by 1 or checks whether the list provided matches that of the incremented one when provided
increment_list(T,Y), 
X is H+1.


%8
list_last([X],X).
list_last([_|T],X) :- %finds the last element of the list, or can find the last element of input provided
list_last(T,X).

%9
list_suffix(X,X).  %basically eliminates the first place and runs through the list as such
list_suffix([_|T],Z) :- 
    list_suffix(T,Z).

%10 
list_concatenation([],X,X).
list_concatenation([Y|T], X, [Y|M]) :- %works by putting elements of a list into a final list with all the members
    list_concatenation(T,X,M).