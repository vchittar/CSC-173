Vishnu Chittari

In this assignment we were assigned to work on trees and lists. The lists were easier to understand than the trees as trees required more patience and learning to truly understand and master them. I feel that I have understood more about these topics from when I have first started this assignment. Starting off these tasks seemed Herculean but these tasks were simplified once I was able to understand how a tree and a list truly worked.

Files Included:
Readme.txt
Tree.pl