/*Vishnu Chittari
Prolog 1 Assignment*/


/* These are the facts that are given in the song */

male(i).
spouse(i,widow).
spouse(widow,i).
female(widow).

child(redhair,widow).
female(redhair).

child(i,dad).
male(dad).

spouse(dad,redhair).
spouse(redhair,dad).

child(onrun,dad).
male(onrun).

child(baby,i).
male(baby).


/*	The rules made to verify the claims	*/
parent(X,Y) :- child(Y,X).
parent(X,Y) :- child(Y,Z), spouse(Z,X).

/*	The dad or mother method identifies if X is the dad or mother of Y	*/
dad(X,Y) :- parent(X,Y), male(X).
mother(X,Y) :- parent(X,Y), female(X).

/*	The daughter method identifies if X is a daughter of Y.		*/
daughter(X,Y) :- child(X,Y), female(X).
daughter(X,Y) :- child(X,A), female(X), spouse(A,Y).

/*	The son method identifies if X is a son of Y.	*/
son(X,Y) :- child(X,Y), male(X).
son(X,Y) :- child(X,A), male(X), spouse(A,Y).

/*	The brother method identifies if X is a brother of Y, assumed that there is a sibling involved	*/
brother(X,Y) :- child(X,A), child(Y,Z), spouse(A,Z), male(X), X \==Y.

/*	The brother_in_law method identifies if X is a brother in law of Y.	*/

brother_in_law(X,Y) :- brother(X,Z), spouse(Z,Y), male(X).

/*	Sibling method */
sibling(X,Y) :- parent(Z,X), parent(W,Y), spouse(Z,W).

son_in_law(X,Y) :- spouse(X,Z), sibling(Z,W), child(W,Y), male(X).
uncle(X,Y) :- spouse(Z,W), sibling(X,Z), parent(W,Y), male(X).

/* Grandparent method and how they are related	 */

grandchild(X,Y) :- parent(Y,Z), parent(Z,X).
grandmother(X,Y) :- parent(X,Z), parent(Z,Y), female(X).
grandfather(X,Y) :- parent(X,Z), parent(Z,Y), male(X).

/*	Additional claims	*/
sister(X,Y) :- child(X,A), child(Y,Z), spouse(A,Z), female(X), X \==Y.

sister_in_law(X,Y) :- sister(X,Z), spouse(Z,Y), female(X).

daughter_in_law(X,Y) :- spouse(X,Z), sibling(Z,W), child(W,Y), female(X).

aunt(X,Y) :- spouse(Z,W), sibling(X,Z), parent(W,Y), female(X).