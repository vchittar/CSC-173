Vishnu Chittari

In this lab we explore different familial relationships and how convaluted it can get in the end. Basically we first start off by stating certain rules that are true about the family and then later we explore on these rules and how they affect each other. We thus have facts to help us ease through these rules. We set up each of these realtionships so it helps us show the "family tree" and how everyone is related to each other. 

How to Run:
1. Type swipl in your unix command shell
2. consult('db.pl').
3. Check cases.

Folder Contains:
Mission.txt
db.pl
README.txt
lyrics.txt