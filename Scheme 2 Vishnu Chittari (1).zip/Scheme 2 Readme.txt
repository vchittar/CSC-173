Vishnu Chittari
Scheme 2

File Contains:
Readme.txt
Scheme2.rkt
Excel Chart for 2.5.2

This scheme lab was the second lab in our Scheme chapters.

2.1 
In this problem we had to represent a trinary treee. My function basically takes in a list and checks if it is empty or not. The equivalent function is basically used for comparision and checks if it is one of the nodes of the tree. It starts off by checking if the tree is empty or not and if it is not the first node is checked and then it is going to be called recursively for the rest of the 3 children nodes if the object exists within the tree.

2.2

In this problem we had to  basically print out an element in a list that was before the given element. So for example if I had (my_precedes-recur'a #(a v a i a s a h)). I would get the result of vish as it takes an element that is before the v. We had to do this twice both recursively and iteraltively. The recursive one was easy enough and i thought it was fairly easy to understand. I ran into a few problems with the iterative one such that everytime i got the answer to print out, i got the answer in reverse and in order to reverse it, I looked up a reverse function and implemented that. I used an external website for the reverse function as I wasnt exactly clear on how to do so. 

2.4

In this problem we had to make a remv function that takes 2 lists to match a function. The first list contains the values that are used to match in those of the second list and whatever elements match in the first. In my function rem-all it first checks the fact that its empty or not, and if its not set! is used to redifne the values and the node-delete is used to delete similar nodes. The node-delete takes in an object and 2 elements used for deletion. First we check if its empty or not and then if its null. Then we proceed to check if the list is empty or not. The function returns null and not an empty list list() because that simplifies operations within rem-all. If its not emepty then the function deltes the necessary nodes in the second one that are in the first one which gives us our answer.

2.5.1

The N-Queens Problem

In this problem we had to calculate the number of attacks of the queens and divided by the number of queens. I successfully did the math function but I didnt have enough time to implement the rest of the functions. If given 2 more hours i would have definetly finished it. I had a clear idea on how to do it. So basically we calucalte the colup_rowleft, coldown_rowleft, colup_rowright, coldown_rowright. And then we add up all the values in order to get our answer. Did a majority of it but I ran out of time. 


2.5.2

In this problem we had to make an explore function in a tree structure. I did this function exaclty as I read the instructions that were given, no extra pizzaz was added to it really. 
A) The function calls
B) When a function calls itself the arc connects it to the calls.
C) The T is essentially a tree so it what we have is the max-level which is the height of the tree and the sum-level is the sum of all the nodes and the node count is the number of nodes in the given tree.
D)The tree is explored as a depth-first. 

As expected we can see that as the max-level increases so does the sum level and the node count of the particular problem. This makes sense as we are increasing the tree and so there will bemore levels for the program to traverse through. 

Links
http://stackoverflow.com/questions/4092113/how-to-reverse-a-list
I used this to write my reverse function.

I also had help from Hunter Johnston on how to start off my nqeens and he helped me approach on how to start 2.5.2 which was extremely helpful. The CSUG tutors helped me debug my code and also helped me with ideas on how to approach 2.5. 