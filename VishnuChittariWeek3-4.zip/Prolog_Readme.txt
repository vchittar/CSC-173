Vishnu Chittari
11/6/2015
CSC 173
Prolog week 3-4 Natural Language Parser

Description: 

The Parser and the Translator was mostly influenced by the Clocks and Mellish Textbook that was on CB's website. The project and many of its parts weere borrowed heavily from the textbook and it was a crucial asset to tackle the problem. The parser was first tacked by stating different rules and then building a parse tree so that we could analyze the sentence that was inputted. 

The translator on the other hand will take the constructed parse tree and build it into a FOPC. 


Folder Contains:

PP3-4.pl- This file is the bulk of the project and contains the natural language parser.

This file mainly contains the parser and translator and some comments explaining how I deduced my code and such. My vocab was mostly the same for both my parser and translator. 

The Parser was implemeted from reading CB's website and the textbook and understanding how a sentence structure actually works. I did add a few arguments here and there to modify CB's code and made the parser, parse a little bit more effeciently. The X is the plurality whereas the the Y is the parse tree. 

The Translator was implemented from reading various materials on CB's website and the textbook, I also added a few arguments to strengthen the overall code for the translator. 

The hardest parts on the translator and the parser were probably implementing the relative clauses for both the parser and the translator. I found this difficult because I did not correctly make the relative clause tree and as a result my parse tree was printing out incorrectly. 


Prolog_Readme.txt- This file contains the basic outline of the project and some sample outputs.
WRITEUP.pdf- This is an a more close look on how the natural language parser contains and how I achieved the results that are seen below.

How to Run it: 
1. Load in a prolog shell.
2. consult('PP3-4.pl').pl /* this will enable you to "make" the file, basically compiling it
3. Run the Parser by : scan(X,Y). /* this will allow you to input the a sentence that you want the parse tree of. X shows the plurality and Y is the parse tree */
4. Run the Translator by : translate(X,Y). 

parse(X,Y).
|: 'Enter your sentence'

translate(X).
|: 'Enter your sentence'

Sample Output:

Parser: 

parse(X,Y).
|: The boys eat apples.
X = singular.
Y = sentence(noun_phrase(det(the), noun(boys)), verb_phrase(verb(eat), noun_phrase(noun(apples))));
false.

?- parse(X,Y).
|:    The boy likes the girl.
X = singular,
Y = sentence(noun_phrase(det(the), noun(boy)), verb_phrase(verb(likes), noun_phrase(det(the), noun(girl)))) ;
false.

?- parse(X,Y).
|: The girl who eats a watermelon likes the boy.
X = singular,
Y = sentence(noun_phrase(det(the), noun(girl), relcl(rel(who), verb_phrase(verb(eats), noun_phrase(det(a), noun(watermelon))))), verb_phrase(verb(likes), noun_phrase(det(the), noun(boy)))) ;
false.

Translator: 

?- translate(X).
|: All girls whom some boy likes like all watermelons.
X = all(x82, (girls(x82)&exists(x83, boy(x83)&likes(x83, x82))->all(x84, (watermelons(x84)->like(x82, x84))))) ;
X = all(x82, (girls(x82)&exists(x83, boy(x83)&likes(x83, x82))->all(x86, (watermelons(x86)->like(x82, x86))))) ;
false.

?- translate(X).
|    All boys whom some girl likes like some watermelon.
X = all(x171, (boys(x171)&exists(x172, girl(x172)&likes(x172, x171))->exists(x173, watermelon(x173)&like(x171, x173)))) .

?- translate(X).
|    Some girl who likes some boy likes all watermelons.
X = exists(x174, (girl(x174)&exists(x175, boy(x175)&likes(x174, x175)))&all(x176, (watermelons(x176)->likes(x174, x176)))) .


Extra Credit:

I think the program successfully implements the following determiners such as a, an, the, some, every, all. This works well on the translator and the parser.


I also made the adjective before the noun work for the translator and the parser(maybe not extra credit for the parser) which was extra credit based on this Piazza post. 
https://piazza.com/class/if02bvgchvw5em?cid=153

?- translate(X).
|: the evil boy runs.
X = all(x34, (evil(x34)->boy(x34))) .


?- parse(X,Y).
|: all evil boy runs.
X = singular,
Y = sentence(noun_phrase(det(all), adj(evil), noun(boy)), verb_phrase(noun(runs))) .
