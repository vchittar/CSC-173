/* Prolog Week 3,4 */
/* Vishnu Chittari */

/*These are the nouns we are going to be using: apple, boy, girl, government, watermelon */

noun(singular,noun(government))-->[government].
noun(plural,noun(governments))-->[governments].

noun(singular,noun(boy))-->[boy].
noun(plural,noun(boys))-->[boys].

noun(singular,noun(girl))-->[girl].
noun(plural,noun(girls))-->[girls].

noun(singular,noun(watermelon))-->[watermelon].
noun(plural,noun(watermelons))-->[watermelons].

noun(singular,noun(apple))-->[apple].
noun(plural,noun(apples))-->[apples].

noun(singular,noun(people))-->[people].
noun(plural,noun(peoples))-->[peoples].


/*These are the determinants we are going to be using: a, the.*/
det(singular,det(a)) --> [a].
det(singular, det(an))--> [an].
det(_,det(the)) --> [the].
det(_,det(some))-->[some].
det(_,det(all))-->[all].

/*These are the verbs we are going to be using: conscript, like, run*/

verb(singular,verb(conscripts))-->[conscripts].
verb(plural,verb(conscript))-->[conscript].

verb(singular,verb(likes))-->[likes].
verb(plural,verb(like))-->[like].

verb(singular,verb(eats))-->[eats].
verb(plural,verb(eat))-->[eat].

verb(singular,noun(runs))-->[runs].
verb(plural,noun(run))-->[run].

/*These are the BeVerbs we are going to be using: is, are*/
beverb(singular, beverb(is)) --> [is].
beverb(plural, beverb(are)) --> [are].

/*Relative clauses: that, whom, who, which.*/
rel(_,rel(that)) --> [that].
rel(_,rel(which)) --> [which].
rel(_,rel(whom)) --> [whom].
rel(_,rel(who)) --> [who].

/* Operands are listed below */

?-op(500,xfy,&).
?-op(600,xfy,=>).

/*The adjective we are going to be using : evil*/

adj(_, adj(evil)) --> [evil]. %put in the space to indicate that it can plural or singular, depening on the rest of the sentence

/*Parser grammar*/
/* This is the parser grammer we are going to be implementing for the method */

parse(X, T) :- read_in(Y), sentence(X,T,Y,[]). %read in method for the parse. 

sentence(X, sentence(NP,VP)) -->noun_phrase(X,NP),verb_phrase(X,VP),sentence_finisher.

noun_phrase(X, noun_phrase(D,N)) --> det(X,D),noun(X,N).
noun_phrase(X, noun_phrase(D,N,RC)) --> det(X,D),noun(X,N),relcl(_,RC).
noun_phrase(X, noun_phrase(D,A,N)) --> det(X,D),adj(_,A),noun(X,N).
noun_phrase(X, noun_phrase(A,N)) --> adj(_,A),noun(X,N).
noun_phrase(X, noun_phrase(D,A,N,RC)) -->det(X,D),adj(_,A),noun(X,N),relcl(_,RC).
noun_phrase(X, noun_phrase(N)) --> noun(X,N).
%noun_phrase(X, noun_phrase(N))

% to implement some cases wihtout determiners

noun_phrase(X, noun_phrase(N,RC)) --> noun(X,N),relcl(_,RC).
noun_phrase(X, noun_phrase(A,N,RC)) --> adj(_,A),noun(X,N),relcl(_,RC).


verb_phrase(X, verb_phrase(V)) --> verb(X,V).
verb_phrase(X, verb_phrase(V,NP)) --> verb(X,V),noun_phrase(_,NP).
verb_phrase(X, verb_phrase(BV,A)) --> beverb(X,BV),adj(_,A).

relcl(X, relcl(RC,VP)) --> rel(_,RC),verb_phrase(X,VP).
relcl(X, relcl(RC,NP,V)) --> rel(_,RC),noun_phrase(X,NP),verb(X,V).

sentence_finisher([X],[]) :- member(X,[.,!,?]).


/* Translator Grammer */
 translate(X) :- read_in(Y), sentence_t(X,Y,_). 

sentence_t(P) --> noun_phrase_t(X,P1,P), verb_phrase_t(X,P1), sentence_finisher.

noun_phrase_t(X,P1,P) --> determiner_t(X,P2,P1,P), noun_t(X,P3), rel_clause_t(X,P3,P2).
noun_phrase_t(X,_,P) --> determiner_t(X,P2,P3,P), adj_t(X,P2), noun_t(X,P3).
 %noun_phrase_t(X,P,P)-->{gensym(x,X)},proper_noun_t(X).

%noun_phrase(X,P1,P)noun_phrase(D,N)) --> det(X,D),noun(X,N).

 verb_phrase_t(X,P)-->trans_verb(X,Y,P1), noun_phrase_t(Y,P1,P).
 verb_phrase_t(X,P)-->noun_phrase_t(Y,P1,P),trans_verb(Y,X,P1).
 
 verb_phrase_t(X,P)-->intrans_verb(X,P).
 verb_phrase_t(X,P1)-->[is],adj_t(X,P1).
 verb_phrase_t(X,P1)-->[are],adj_t(X,P1).

 %verb_phrase_t(X,P)-->beverb_t(X),adj_t(X,P).

 /* The relative clauses for the translator */


rel_clause_t(X,P1,(P1&P2))-->[that],verb_phrase_t(X,P2).
rel_clause_t(X,P1,(P1&P2))-->[whom],verb_phrase_t(X,P2).
rel_clause_t(X,P1,(P1&P2))-->[which],verb_phrase_t(X,P2).
rel_clause_t(X,P1,(P1&P2))-->[who],verb_phrase_t(X,P2).
rel_clause_t(_,P,P)-->[].

%rel_clause_t(X,P1,(P1&P2))-->[that],noun_phrase_t(Y,P2,P3),trans_verb(Y,X,P2).


/* The determiners for the translator */

 determiner_t(X,P1,P2,all(X,(P1->P2)))-->[every],{gensym(x,X)}.
 determiner_t(X,P1,P2,all(X,(P1->P2)))-->[all],{gensym(x,X)}.
 determiner_t(X,P1,P2,all(X,(P1->P2)))-->[the],{gensym(x,X)}.
 determiner_t(X,P1,P2,exists(X,(P1&P2)))-->[the],{gensym(x,X)}.
 determiner_t(X,P1,P2,exists(X,(P1&P2)))-->[a],{gensym(x,X)}.
  determiner_t(X,P1,P2,exsists(X,(P1&P2)))-->[some],{gensym(x,X)}.
 determiner_t(X,P1,P2,all(X,(P1->P2)))-->[some],{gensym(x,X)}.
 determiner_t(X,P1,P2,exists(X,(P1&P2)))-->[an],{gensym(x,X)}.
 determiner_t(X,P1,P2,exists(X,(P1&P2))) --> [].
 %determiner_t(X,P1,P2,exists(X,(P1&P2)))-->[some].


/* The nouns for the Translator */

noun_t(X,man(X))-->[man].
noun_t(X,woman(X))-->[woman].
noun_t(X,apple(X))-->[apple].
noun_t(X,apples(X))-->[apples].
noun_t(X,boy(X))-->[boy].
noun_t(X,boys(X))-->[boys].
noun_t(X,girl(X))-->[girl].
noun_t(X,girls(X))-->[girls].
noun_t(X,government(X))-->[government].
noun_t(X,watermelon(X))-->[watermelon].
noun_t(X,watermelons(X))-->[watermelons].
noun_t(X,people(X))-->[people].

%proper_noun(john)-->[john].


/* The verbs required for the trasnlator */
trans_verb(X,Y,loves(X,Y))-->[loves].
trans_verb(X,Y,love(X,Y))-->[love].
trans_verb(X,Y,like(X,Y))-->[like].
trans_verb(X,Y,likes(X,Y))-->[likes].
trans_verb(X,Y,run(X,Y))-->[run].
trans_verb(X,Y,runs(X,Y))-->[runs].

trans_verb(X,Y,conscript(X,Y))-->[conscript].
trans_verb(X,Y,conscripts(X,Y))-->[conscripts].

intrans_verb(X,lives(X))-->[lives].
intrans_verb(X,live(X))-->[live].
intrans_verb(X,run(X))-->[run].
intrans_verb(X,runs(X))-->[runs].



/*Adj*/

adj_t(X,evil(X))-->[evil].

/*Beverb- Didnt seem to be working if I did it this way so, I just plugged them above*/

%beverb_t(X,is(X))-->[is].
%beverb_t(X,are(X))-->[are].



read_in([W|Ws]) :- get_char(C),
                   readword(C,W,C1),
                   restsent(W,C1,Ws).

restsent(W, _, []) :- lastword(W),!.
restsent(_, C, [W1|Ws]) :- readword(C,W1,C1),
	                   restsent(W1,C1,Ws).

readword(C,C,C1) :- single_character(C),!,get_char(C1).
readword(C,W,C2) :-
	in_word(C, NewC),
	!,
	get_char(C1),
	restword(C1,Cs,C2),
	atom_chars(W,[NewC|Cs]).
readword(_,W,C2):-get_char(C1),readword(C1,W,C2). 

restword(C,[NewC|Cs],C2) :-
	in_word(C,NewC),
	!,
	get_char(C1),restword(C1,Cs,C2).
restword(C,[],C).

in_word(C,C) :- letter(C,_).
in_word(C,L) :- letter(L,C).
in_word(C,C) :- digit(C).
in_word(C,C) :- special_character(C).

special_character('-').
special_character('''').

single_character(',').          
single_character(':').
single_character('.').          
single_character('?').
single_character(';').          
single_character('!').

letter(a,'A').		  letter(n,'N').
letter(b,'B').		  letter(o,'O').
letter(c,'C').		  letter(p,'P').
letter(d,'D').		  letter(q,'Q').
letter(e,'E').		  letter(r,'R').
letter(f,'F').		  letter(s,'S').
letter(g,'G').		  letter(t,'T').
letter(h,'H').		  letter(u,'U').
letter(i,'I').		  letter(v,'V').
letter(j,'J').		  letter(w,'W').
letter(k,'K').		  letter(x,'X').
letter(l,'L').		  letter(y,'Y').
letter(m,'M').		  letter(z,'Z').

digit('0').        digit('5').
digit('1').        digit('6').
digit('2').        digit('7').
digit('3').        digit('8').
digit('4').        digit('9').

lastword('.').
lastword('!').
lastword('?').